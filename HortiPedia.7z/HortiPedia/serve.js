import 'dotenv/config';
import express from 'express';
import mongoose from 'mongoose';
const app = express();
app.use(express.json());

// Conectar no MongoDB Atlas
mongoose.connect(process.env.MONGODB_URI, { dbName: 'hortipedia_db' })
.then(() => console.log('Conectado ao MongoDB'))
.catch(err => console.error('Erro na conexão:', err.message));

// Modelo Vegetal
const vegetalSchema = new mongoose.Schema ({
    nome: { type: String, required: true},
    nome_cientifico: { type: String},
    descricao: { type: String},
    categoria: { type: String },
    calorias_100g: { type: Number},
    vitaminas: { type: [String] },
    estacoes_plantio: { type: [String] },
    imagem: { type: String }
    }, { collection: 'Vegetais', timestamps: true });
    const Vegetal = mongoose.model('Vegetal', vegetalSchema, 'Vegetais');

// Rota inicial
app.get('/', (req, res) => res.json({ msg: 'API rodando' }));
// Criar vegetal
app.post('/vegetais', async (req, res) => {
    const vegetal = await Vegetal.create(req.body);
    res.status(201).json(vegetal);
});

// Listar vegetais
app.get('/vegetais', async (req, res) => {
    const vegetais = await Vegetal.find();
    res.json(vegetais);
    });

// Iniciar servidor
app.listen(process.env.PORT, () =>
    console.log(Servidor rodando em http://localhost:${process.env.PORT}`)
);